---
name: casino-run-next
description: Internal one-work-unit driver used by fresh casino-session processes.
disable-model-invocation: true
user-invocable: true
allowed-tools: Read Write Edit Glob Grep Skill Agent
---
Execute exactly ONE atomic unit, checkpoint, emit continuation signal, stop.
1. Read global batch-state. Selection priority: existing `in_progress` casino; else first `pending`. Never select another casino after this unit. If none: write `batch.done`, remove/ignore active, stop.
2. Claim selected casino if pending; initialize per-casino directory, 12 `{"rows":[]}` files, `research-state.json`, `evidence.jsonl`, `handoff.json`, `captures/`, `work/`. Never copy credential content to state.
3. Select one next unit only:
   a. no coverage plan -> `coverage_plan`;
   b. auth pending -> `auth`;
   c. frontier has `retry_pending` then `pending` -> one `surface`;
   d. all surfaces terminal -> `final_audit`;
   e. resolved human handoff not applied -> `human_resolution_apply`.
4. Delegate using role agents. Browser work only auth-browser/surface-browser; raw analysis only snapshot-extractor; output/state writes only state-writer; final gate only coverage-auditor.
5. Surface transient failure: set `retry_pending` after attempt 1 and end unit. Attempt 2 occurs next top-level session; second failure -> handoff. No same-session retry.
6. Commit checkpoint after delegated writes. If batch/current casino has more work or later pending casinos, write `.runtime/casino/spawn-next`; else write `batch.done`.
7. Stop. Never execute second unit.
